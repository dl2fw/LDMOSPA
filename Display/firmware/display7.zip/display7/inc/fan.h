/*
 * fan.h
 *
 *  Created on: 07.07.2018
 *      Author: kurt
 */

#ifndef FAN_H_
#define FAN_H_

void fan_timer();
void do_fan();

#endif /* FAN_H_ */
